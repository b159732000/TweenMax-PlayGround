(function($) {

	// Our code will go here

})(jQuery);